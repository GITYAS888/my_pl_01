public class app {
    public static void main(String[] args) {
      
        
        final int MAX_SCORE = 100;
        
        
        int score = 88;
        
        
        System.out.println("Maximum Score: " + MAX_SCORE);
        System.out.println("Current Score: " + score);
    }
}