public class app {

    public static void main(final String[] args) {

    
    int age = 30;
    float temprature = 23.6f;
    char initial = 'Y';

    System.out.println(age);
    System.out.println(temprature);
    System.out.println(initial);
    }
}




