public class app {
    public static void main(final String[] args) {
       
        int x = 10;
        float y = 5.5f;
        boolean flag = true;
        char letter = 'c';
        short year = 2022;
        long population = 7000000000L;
        byte num = 100;
        double pi = 3.13457599923384753929348;

       
        System.out.println(x);
        System.out.println(y);
        System.out.println(flag);
        System.out.println(letter);
        System.out.println(year);
        System.out.println(population);
        System.out.println(num);
        System.out.println(pi);
    }
}