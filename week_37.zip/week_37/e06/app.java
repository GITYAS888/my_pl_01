public class app {
    public static void main(final String[] args)
     {
        
        boolean isJavaFun = true;
        boolean isFishTasty = false;

        
        System.out.println("isJavaFun && isFishTasty: " + (isJavaFun && isFishTasty));
        System.out.println("isJavaFun || isFishTasty: " + (isJavaFun || isFishTasty));
        System.out.println("!isJavaFun: " + !isJavaFun);
        System.out.println("!isFishTasty: " + !isFishTasty);
    }
}