public class app{
    public static void main(final String[] args) {
        int a = 66;
        int b = 56;

        System.out.println("Sum: " + (a + b));
        System.out.println("Difference: " + (a - b));
        System.out.println("Product: " + (a * b));
        System.out.println("Quotient: " + (a / b));
        System.out.println("Modulo: " + (a % b));

              
    }
}






     

















