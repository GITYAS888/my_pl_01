public class app {
    public static void main(final String[] args) {
        
        int num = 88;
        float decimal = 3.8f;

        
        double sum = num + decimal;
        System.out.println("Sum: " + sum);

        
        int sumInt = (int) sum;
        System.out.println("Sum (int): " + sumInt);
    }
}